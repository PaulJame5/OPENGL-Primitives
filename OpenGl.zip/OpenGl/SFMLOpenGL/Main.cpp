#include <Game.h>

int main(void)
{
	Game& game = Game();
	game.run();
}